
import java.util.Scanner;

public class main {

    public static void main(String[] args) throws Exception {
        Scanner cap = new Scanner(System.in);
        Funcoes f = new Funcoes();

        f.calculaFGTS();
    }

}
